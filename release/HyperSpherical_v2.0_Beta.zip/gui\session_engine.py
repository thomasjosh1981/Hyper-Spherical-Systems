# gui/session_engine.py
#
# Hyper-Spherical Systems — Python implementation of the M2M+SISSI+5+1 pipeline
#
# This mirrors session_cipher.cpp / sissi_handshake.cpp for the web dashboard.
# Runs inside the Flask server so the UI can open live compressed cloud sessions.
#
# Pipeline (local → cloud):
#   Plaintext → M2M prose elimination → SISSI §codes → 5+1 Homophonic Unicode
#
# License: MIT

import os
import re
import json
import math
import random
import string
import time
import struct
import threading
import urllib.request
import urllib.error
from dataclasses import dataclass, field
from typing import Optional, Dict, List, Tuple

# ── SISSI Built-in Dictionary ─────────────────────────────────────────────────
SISSI_DICT = [
    # code,  expansion,  bidirectional
    ("§YHA",  "You are a helpful assistant",           True),
    ("§SYS",  "System:",                               True),
    ("§USR",  "User:",                                 True),
    ("§AST",  "Assistant:",                            True),
    ("§PP",   "Please provide",                        True),
    ("§BOC",  "Based on the context",                  True),
    ("§IS",   "In summary",                            True),
    ("§TFI",  "The following is",                      True),
    ("§AALM", "As an AI language model",               True),
    ("§IUT",  "I understand that",                     True),
    ("§TYY",  "Thank you for your",                    True),
    ("§LMKYH","Let me know if you have",               True),
    ("§CYP",  "Could you please",                      True),
    ("§ATTI", "According to the information provided", True),
    ("§IITN", "It is important to note that",          True),
    ("§ITHH", "I hope this helps",                     True),
    ("§PNT",  "Please note that",                      True),
    ("§IWBH", "I would be happy to",                   True),
    ("§FFTA", "Feel free to ask",                      True),
    ("§HAS",  "Here are some",                         True),
    ("§KPA",  "The key points are",                    True),
    ("§IC",   "In conclusion",                         True),
    ("§FTH",  "Furthermore",                           True),
    ("§ADL",  "Additionally",                          True),
    ("§HWV",  "However",                               True),
    ("§TFR",  "Therefore",                             True),
    ("§NTL",  "Nevertheless",                          True),
    ("§CSQ",  "Consequently",                          True),
    ("§IWNT", "It is worth noting that",               True),
    ("§IOW",  "In other words",                        True),
    ("§TSM",  "To summarize",                          True),
    ("§FAF",  "First and foremost",                    True),
    ("§IMPL", "Here is the implementation",            True),
    ("§EXPL", "Here is an explanation",                True),
    ("§FN",   "function",                              True),
    ("§RET",  "return",                                True),
    ("§ERR",  "error",                                 True),
    # HSS domain
    ("§GCS",  "Golden Candy Spinner",                  True),
    ("§SFS",  "Self-Forming Sphere",                   True),
    ("§SFSP", "Self-Forming Sphere Plus",              True),
    ("§HSCC", "Hyper-Spherical Coordinate Compression",True),
    ("§SISSI","SISSI compression",                     True),
    ("§CCTM", "Cloud Token Compression Module",        True),
    ("§UEP",  "Universal Endpoint",                    True),
    ("§GGUF", "GGUF model format",                     True),
    ("§HFS",  "HuggingFace",                           True),
    ("§VMOE", "Virtual Mixture of Experts",            True),
]

# ── M2M Prose Elimination Rules ───────────────────────────────────────────────
M2M_RULES: List[Tuple[str, str]] = [
    ("I would like to", ""),
    ("I am going to", ""),
    ("please note that", ""),
    ("it is important to note that", ""),
    ("as I mentioned earlier", "[R:prev]"),
    ("as mentioned previously", "[R:prev]"),
    ("as stated above", "[R:prev]"),
    ("based on the information provided", "BOC"),
    ("according to the context", "BOC"),
    ("with that said", ""),
    ("that being said", ""),
    ("in other words", "IOW:"),
    ("to put it simply", "IOW:"),
    ("to summarize", "SUM:"),
    ("in summary", "SUM:"),
    ("in conclusion", "END:"),
    ("to conclude", "END:"),
    ("furthermore", "+"),
    ("additionally", "+"),
    ("moreover", "+"),
    ("however", "BUT:"),
    ("on the other hand", "BUT:"),
    ("nevertheless", "BUT:"),
    ("therefore", "→"),
    ("consequently", "→"),
    ("as a result", "→"),
    ("it follows that", "→"),
    ("successfully completed", "OK"),
    ("completed successfully", "OK"),
    ("this works correctly", "OK"),
    ("no issues found", "OK"),
    ("failed to", "ERR:"),
    ("unable to", "ERR:"),
    ("error occurred", "ERR"),
    ("warning:", "WARN:"),
    ("is true", ":T"),
    ("is false", ":F"),
    ("is enabled", ":ON"),
    ("is disabled", ":OFF"),
    ("is not", ":F"),
    ("does not", "!"),
    (". furthermore", "|+"),
    (". additionally", "|+"),
    (". however", "|BUT:"),
    (". therefore", "|→"),
    (". in conclusion", "|END:"),
]

# ── Unicode symbol pools (single-token in GPT-4o, Claude, Llama-3) ────────────
# High-frequency chars: e t a o i n s h r l  (10 chars × 10 candidates)
HIGH_FREQ_CHARS  = list("etaoinshrl")
HIGH_FREQ_POOL   = [
    ["ë","é","ê","è","ě","ę","ε","е","э","ė"],   # e
    ["τ","т","ţ","ť","ŧ","ƭ","ț","ʈ","ẗ","ṭ"],   # t
    ["à","á","â","ã","ā","ă","ą","α","а","ȁ"],   # a
    ["ò","ó","ô","õ","ō","ő","ø","ο","о","ȍ"],   # o
    ["ì","í","î","ï","ī","ĭ","į","ι","и","ȉ"],   # i
    ["ñ","ń","ň","ņ","ŋ","ν","н","ṅ","ṇ","ṉ"],   # n
    ["ś","š","ş","ŝ","ṡ","ṣ","σ","с","ṩ","ʂ"],   # s
    ["ħ","ĥ","η","ḥ","ḣ","ḧ","ḩ","ẖ","ʰ","ℎ"],   # h
    ["ŕ","ř","ŗ","ρ","р","ṙ","ṛ","ṝ","ṟ","ȑ"],   # r
    ["ĺ","ļ","ľ","ŀ","λ","л","ḷ","ḹ","ḻ","ḽ"],   # l
]

# Mid-frequency chars: d c u m p f g w y b  (10 chars × 6 candidates)
MID_FREQ_CHARS   = list("dcumpfgwyb")
MID_FREQ_POOL    = [
    ["ď","δ","д","ḋ","ḍ","ḏ"],   # d
    ["ć","č","ç","χ","с","ċ"],   # c
    ["ù","ú","û","ū","υ","у"],   # u
    ["μ","м","ṁ","ṃ","ḿ","ṁ"],   # m
    ["π","р","ṗ","ṕ","ṕ","ƥ"],   # p
    ["ƒ","φ","ḟ","ф","ẛ","ᶠ"],   # f
    ["ĝ","ğ","ġ","ģ","γ","г"],   # g
    ["ŵ","ω","ẇ","ẉ","ẘ","ʷ"],   # w
    ["ý","ÿ","ŷ","γ","ψ","у"],   # y
    ["β","б","ƀ","ḃ","ḅ","ḇ"],   # b
]

# Low-frequency chars: z k q x j v  (each gets 1 of 3)
LOW_FREQ_CHARS   = list("zkqxjv")
LOW_FREQ_POOL    = ["ž","ξ","ƿ","ż","κ","þ","ź","к","Þ"]


# ════════════════════════════════════════════════════════════════════════════
# SISSICodec
# ════════════════════════════════════════════════════════════════════════════

class SISSICodec:
    def __init__(self):
        # Sort by expansion length descending for longest-match encoding
        self._entries = sorted(SISSI_DICT, key=lambda x: -len(x[1]))
        self._encode  = {exp: code for code, exp, bi in self._entries}
        self._decode  = {code: exp  for code, exp, bi in self._entries}

    def encode(self, text: str) -> Tuple[str, int, int]:
        """Returns (encoded, original_tokens, compressed_tokens)"""
        result = text
        for exp, code in self._encode.items():
            result = result.replace(exp, code)
        orig = max(1, math.ceil(len(text)   / 4))
        comp = max(1, math.ceil(len(result) / 4))
        return result, orig, comp

    def decode(self, text: str) -> str:
        result = text
        for code, exp in self._decode.items():
            result = result.replace(code, exp)
        return result

    def dict_to_inline(self) -> str:
        parts = ["SISSI_DICT_V1"]
        for code, exp, bi in SISSI_DICT:
            if bi:
                parts.append(f"{code}={exp}")
        return "|".join(parts)

    def token_cost(self) -> int:
        return math.ceil(len(self.dict_to_inline()) / 4) + 80


# ════════════════════════════════════════════════════════════════════════════
# HomophonicTable  (5+1 session-seeded)
# ════════════════════════════════════════════════════════════════════════════

class HomophonicTable:
    def __init__(self, seed: int):
        rng = random.Random(seed)
        self.encode: Dict[str, str]  = {}  # char → symbol
        self.decode: Dict[str, str]  = {}  # symbol → char
        self.table_str               = ""  # compact repr for handshake

        lines = []
        for i, c in enumerate(HIGH_FREQ_CHARS):
            pool = HIGH_FREQ_POOL[i][:]
            rng.shuffle(pool)
            chosen = pool[:5]  # 5 variants
            choice = rng.randint(0, 4)
            sym = chosen[choice]
            self.encode[c] = sym
            self.decode[sym] = c
            lines.append(f"{c}:{','.join(chosen)}")

        for i, c in enumerate(MID_FREQ_CHARS):
            pool = MID_FREQ_POOL[i][:]
            rng.shuffle(pool)
            chosen = pool[:3]  # 3 variants
            choice = rng.randint(0, 2)
            sym = chosen[choice]
            self.encode[c] = sym
            self.decode[sym] = c
            lines.append(f"{c}:{','.join(chosen)}")

        for i, c in enumerate(LOW_FREQ_CHARS):
            sym = rng.choice(LOW_FREQ_POOL)
            self.encode[c] = sym
            self.decode[sym] = c
            lines.append(f"{c}:{sym}")

        self.table_str = "|".join(lines)

    def apply(self, text: str) -> str:
        out = []
        for ch in text:
            out.append(self.encode.get(ch, ch))
        return "".join(out)

    def reverse(self, text: str) -> str:
        # Scan multi-byte sequences
        result = ""
        i = 0
        while i < len(text):
            matched = False
            for length in (3, 2, 1):
                substr = text[i:i+length]
                if substr in self.decode:
                    result += self.decode[substr]
                    i += length
                    matched = True
                    break
            if not matched:
                result += text[i]
                i += 1
        return result


# ════════════════════════════════════════════════════════════════════════════
# M2M Prose Eliminator
# ════════════════════════════════════════════════════════════════════════════

def m2m_encode(text: str) -> str:
    result = text
    for find, repl in M2M_RULES:
        result = re.sub(re.escape(find), repl, result, flags=re.IGNORECASE)
    # Collapse whitespace
    result = re.sub(r"  +", " ", result).strip()
    return result

def m2m_decode(text: str) -> str:
    result = text
    for find, repl in reversed(M2M_RULES):
        if repl:
            result = result.replace(repl, find)
    return result


# ════════════════════════════════════════════════════════════════════════════
# SessionCipher  (full 3-stage pipeline)
# ════════════════════════════════════════════════════════════════════════════

@dataclass
class EncodeStats:
    original_tokens:    int   = 0
    compressed_tokens:  int   = 0
    m2m_savings:        int   = 0
    sissi_savings:      int   = 0
    homo_savings:       int   = 0
    ratio:              float = 1.0
    encoded:            str   = ""

@dataclass
class SessionStats:
    total_messages:         int   = 0
    total_tokens_in:        int   = 0
    total_tokens_out:       int   = 0
    total_tokens_saved:     int   = 0
    overall_ratio:          float = 1.0
    session_token:          str   = ""
    provider:               str   = ""
    model:                  str   = ""
    handshake_tokens_cost:  int   = 0
    handshake_status:       str   = "not_started"
    ack_message:            str   = ""


class SessionCipher:
    def __init__(self, seed: Optional[int] = None):
        if seed is None:
            seed = random.getrandbits(64)
        self.seed         = seed
        self.session_token = f"{seed & 0xFFFFFFFF:08X}"
        self.active       = True
        self.sissi        = SISSICodec()
        self.homo         = HomophonicTable(seed)
        self._torn_down   = False

    def encode(self, plaintext: str) -> EncodeStats:
        if self._torn_down:
            return EncodeStats(encoded=plaintext)
        orig_tokens = max(1, math.ceil(len(plaintext) / 4))

        # Stage 1: M2M
        stage1 = m2m_encode(plaintext)
        m2m_tokens = max(1, math.ceil(len(stage1) / 4))
        m2m_saved  = orig_tokens - m2m_tokens

        # Stage 2: SISSI
        stage2, _, sissi_out_tok = self.sissi.encode(stage1)
        sissi_saved = m2m_tokens - sissi_out_tok

        # Stage 3: 5+1 Homophonic
        stage3 = self.homo.apply(stage2)
        homo_tokens = max(1, math.ceil(len(stage3) / 4))
        homo_saved  = sissi_out_tok - homo_tokens

        ratio = orig_tokens / homo_tokens if homo_tokens > 0 else 1.0

        return EncodeStats(
            original_tokens   = orig_tokens,
            compressed_tokens = homo_tokens,
            m2m_savings       = max(0, m2m_saved),
            sissi_savings     = max(0, sissi_saved),
            homo_savings      = max(0, homo_saved),
            ratio             = ratio,
            encoded           = stage3,
        )

    def decode(self, encoded: str) -> str:
        if self._torn_down:
            return encoded
        stage2 = self.homo.reverse(encoded)
        stage1 = self.sissi.decode(stage2)
        return m2m_decode(stage1)

    def build_handshake_index(self) -> str:
        parts = [
            f"HSYS:SESS:v2|TOK:{self.session_token}",
            "M2M:v1|" + "|".join(f"{f}→{r}" for f,r in M2M_RULES if r),
            "SISSI:v1|" + self.sissi.dict_to_inline(),
            "HOMO:v1|" + self.homo.table_str,
            "RULES:decode_only=F,m2m=T,pipe=M2M>SISSI>HOMO,prose=F,ack=SESS_ACK:OK",
            "END",
        ]
        return "\n".join(parts)

    def handshake_token_cost(self) -> int:
        idx = self.build_handshake_index()
        return math.ceil(len(idx) / 4) + 150

    def teardown(self):
        self.active = False
        self._torn_down = True
        self.seed = 0
        self.homo.encode.clear()
        self.homo.decode.clear()


# ════════════════════════════════════════════════════════════════════════════
# API Clients
# ════════════════════════════════════════════════════════════════════════════

SYSTEM_PROMPT = (
    "You are operating in MACHINE-TO-MACHINE (M2M) compression mode. "
    "CRITICAL RULES:\n"
    "1. LOAD the HSYS session index in the first user message.\n"
    "2. ALL subsequent messages are encoded: M2M notation → SISSI §codes → Homophonic Unicode.\n"
    "3. RESPOND in the same encoding. NEVER use prose when a code exists.\n"
    "4. M2M: use | as sentence separator, → for causation, + for addition, "
    "BOC=based on context, SUM: OK ERR: [R:prev] for back-refs.\n"
    "5. Omit ALL filler: 'I would like to', 'please note that', etc.\n"
    "6. Use §codes for any matching phrase from the SISSI dict.\n"
    "7. Apply Homophonic substitution to remaining chars.\n"
    "8. Session index is ephemeral — expires when conversation ends.\n"
    "Acknowledge ONLY with: SESS_ACK:OK then your compressed self-description."
)


def _post_json(url: str, body: dict, headers: dict, timeout: int = 30) -> dict:
    data = json.dumps(body).encode()
    req  = urllib.request.Request(url, data=data, headers={
        "Content-Type": "application/json", **headers
    }, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read())
    except urllib.error.HTTPError as e:
        return {"error": str(e), "body": e.read().decode(errors="replace")}
    except Exception as e:
        return {"error": str(e)}


def call_openai(model: str, api_key: str, system: str, user: str,
                base_url: str = "https://api.openai.com/v1") -> str:
    resp = _post_json(f"{base_url}/chat/completions",
        {"model": model, "messages": [
            {"role": "system", "content": system},
            {"role": "user",   "content": user},
        ], "max_tokens": 512},
        {"Authorization": f"Bearer {api_key}"},
    )
    try:
        return resp["choices"][0]["message"]["content"]
    except Exception:
        return resp.get("error", str(resp))


def call_anthropic(model: str, api_key: str, system: str, user: str) -> str:
    resp = _post_json("https://api.anthropic.com/v1/messages",
        {"model": model, "max_tokens": 512, "system": system,
         "messages": [{"role": "user", "content": user}]},
        {"x-api-key": api_key, "anthropic-version": "2023-06-01"},
    )
    try:
        return resp["content"][0]["text"]
    except Exception:
        return resp.get("error", str(resp))


def call_google(model: str, api_key: str, user: str) -> str:
    url = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent?key={api_key}"
    resp = _post_json(url,
        {"contents": [{"parts": [{"text": user}]}],
         "generationConfig": {"maxOutputTokens": 512}},
        {},
    )
    try:
        return resp["candidates"][0]["content"]["parts"][0]["text"]
    except Exception:
        return resp.get("error", str(resp))


def call_ollama(model: str, system: str, user: str,
                host: str = "http://localhost:11434") -> str:
    resp = _post_json(f"{host}/api/chat",
        {"model": model, "stream": False, "messages": [
            {"role": "system", "content": system},
            {"role": "user",   "content": user},
        ]},
        {},
    )
    try:
        return resp["message"]["content"]
    except Exception:
        return resp.get("error", str(resp))


# ════════════════════════════════════════════════════════════════════════════
# CloudSession  (manages state for a live web UI session)
# ════════════════════════════════════════════════════════════════════════════

class CloudSession:
    def __init__(self, provider: str, model: str, api_key: str = "",
                 base_url: str = ""):
        self.provider  = provider
        self.model     = model
        self.api_key   = api_key or os.environ.get(_env_key(provider), "")
        self.base_url  = base_url
        self.cipher    = SessionCipher()
        self.stats     = SessionStats(
            session_token = self.cipher.session_token,
            provider      = provider,
            model         = model,
        )
        self._lock     = threading.Lock()
        self._history  = []   # [(compressed_in, raw_out, decoded_out)]
        self._open     = False

    def _call(self, system: str, user: str) -> str:
        p = self.provider
        if p in ("openai", "openai_compat"):
            return call_openai(self.model, self.api_key, system, user,
                               self.base_url or "https://api.openai.com/v1")
        elif p == "anthropic":
            return call_anthropic(self.model, self.api_key, system, user)
        elif p == "google":
            return call_google(self.model, self.api_key, user)
        elif p == "ollama":
            return call_ollama(self.model, system, user,
                               self.base_url or "http://localhost:11434")
        else:
            return call_openai(self.model, self.api_key, system, user,
                               self.base_url or "https://api.openai.com/v1")

    def open(self) -> SessionStats:
        idx  = self.cipher.build_handshake_index()
        cost = self.cipher.handshake_token_cost()
        self.stats.handshake_tokens_cost = cost
        self.stats.handshake_status = "negotiating"

        negotiate_msg = (
            "I am sharing a compression dictionary for our session. "
            "Please load it and acknowledge.\n\n" + idx
        )

        ack = self._call(SYSTEM_PROMPT, negotiate_msg)
        self.stats.ack_message = ack

        if "SESS_ACK:OK" in ack:
            self.stats.handshake_status = "success"
            self._open = True
        elif ack and "error" not in ack.lower()[:20]:
            self.stats.handshake_status = "partial"
            self._open = True
        else:
            self.stats.handshake_status = "failed"

        return self.stats

    def chat(self, plaintext: str) -> dict:
        with self._lock:
            if not self._open:
                return {"error": "Session not open"}

            enc = self.cipher.encode(plaintext)
            raw_resp = self._call(
                "Maintain the HSYS session compression from the start of our conversation.",
                enc.encoded,
            )
            decoded = self.cipher.decode(raw_resp)

            self.stats.total_messages    += 1
            self.stats.total_tokens_in   += enc.original_tokens
            self.stats.total_tokens_out  += enc.compressed_tokens
            self.stats.total_tokens_saved = (
                self.stats.total_tokens_in - self.stats.total_tokens_out
            )
            if self.stats.total_tokens_out > 0:
                self.stats.overall_ratio = (
                    self.stats.total_tokens_in / self.stats.total_tokens_out
                )

            entry = {
                "msg_num":           self.stats.total_messages,
                "plaintext_in":      plaintext,
                "encoded_in":        enc.encoded,
                "tokens_in_orig":    enc.original_tokens,
                "tokens_in_comp":    enc.compressed_tokens,
                "m2m_savings":       enc.m2m_savings,
                "sissi_savings":     enc.sissi_savings,
                "homo_savings":      enc.homo_savings,
                "msg_ratio":         round(enc.ratio, 2),
                "raw_response":      raw_resp,
                "decoded_response":  decoded,
                "session_ratio":     round(self.stats.overall_ratio, 2),
                "total_saved":       self.stats.total_tokens_saved,
            }
            self._history.append(entry)
            return entry

    def close(self) -> SessionStats:
        self._open = False
        self.cipher.teardown()
        return self.stats

    def get_stats(self) -> dict:
        return {
            "session_token":        self.stats.session_token,
            "provider":             self.stats.provider,
            "model":                self.stats.model,
            "handshake_status":     self.stats.handshake_status,
            "handshake_cost":       self.stats.handshake_tokens_cost,
            "total_messages":       self.stats.total_messages,
            "total_tokens_in":      self.stats.total_tokens_in,
            "total_tokens_out":     self.stats.total_tokens_out,
            "total_tokens_saved":   self.stats.total_tokens_saved,
            "overall_ratio":        round(self.stats.overall_ratio, 2),
            "is_open":              self._open,
            "history":              self._history[-20:],  # last 20 exchanges
        }

    @staticmethod
    def preview_compression(text: str) -> dict:
        """Stateless preview — shows what the pipeline would do to a text."""
        c = SessionCipher(seed=42)  # fixed seed for preview
        enc = c.encode(text)
        return {
            "original":           text,
            "after_m2m":          m2m_encode(text),
            "after_sissi":        c.sissi.encode(m2m_encode(text))[0],
            "after_all":          enc.encoded,
            "original_tokens":    enc.original_tokens,
            "compressed_tokens":  enc.compressed_tokens,
            "ratio":              round(enc.ratio, 2),
            "m2m_savings":        enc.m2m_savings,
            "sissi_savings":      enc.sissi_savings,
            "homo_savings":       enc.homo_savings,
        }


# ── Helpers ───────────────────────────────────────────────────────────────────
def _env_key(provider: str) -> str:
    return {
        "openai":       "OPENAI_API_KEY",
        "anthropic":    "ANTHROPIC_API_KEY",
        "google":       "GOOGLE_API_KEY",
        "openai_compat":"OPENAI_COMPAT_KEY",
    }.get(provider, "")
